let ifa=document.querySelector('.cbfoodinfo .jutiinfo iframe');


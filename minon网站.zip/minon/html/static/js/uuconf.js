var uurl='http://106.14.198.191:8000/';

try{

var uuuid=sessionStorage.getItem('id');

}catch(e){}

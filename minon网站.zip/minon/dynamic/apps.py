from django.apps import AppConfig


class DynamicConfig(AppConfig):
    name = 'dynamic'
